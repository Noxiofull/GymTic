<?php 
session_start();


require_once './php/conexion.php';

  if(!isset($_SESSION['usuario'])){
      
    echo '
        <script>
            window.location = "login.html";
        </script>
    ';
    session_destroy();
}
else{
    $nombre = $_SESSION['usuario'];
 
    $query = "SELECT * FROM usuarios";
    $ejecutar = mysqli_query($conexion, $query);
                    
    while($linea = mysqli_fetch_array($ejecutar)){
        if($nombre == $linea['nombre']){

            $id = $linea['id'];
            $puntos = $linea['puntos'];
            break;
        }      
    }

    $porcentaje = ($puntos % 10)*10;
    $rango = (int)($puntos / 10);
    
    $array = array("Novato", "Semi-Novato", "Experimentado", "Loco por los ejercicios","Emperador","Mastodonte","Rey del gym");
    
    if($rango>6){
      $rango_tex = $array[6];
      $rango_tex2 = "Proximamente";
      $porcentaje = 100;
    }else{
      $rango_tex = $array[($rango-1 >=0)?$rango-1:0];
      $rango_tex2 = $array[($rango == 0)?$rango+1:0];
    }
    
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Import Google Icon Font-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Compiled and minified CSS -->
<link rel="stylesheet" href="cambios.css">
<!--Import materialize.css-->
<link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
<!-- <link rel="stylesheet" href="circulo.css?1.1"> -->

<!--Let browser know website is optimized for mobile-->
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body style="overflow:hidden">
    <div class="principal">
        <header>
            <nav>
            <div class="nav-wrapper red">
                <div class="card_2" style="padding: 0;justify-content:left;">
                <a href="index.php"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a>
                    <p style="color: white; font-size: 20px;padding-left: 90px;">Recompensas</p>
                </div>
            </div>
          </nav>
        </header>
        <main>
            <div class="container_3" style="background:white;">
                <div class="bar">
                  <svg>
                    <circle cx='50%' cy='50%' r="50%"></circle>
                  </svg>
                  
                  <h1>LOGRO<br><?php echo $porcentaje ?>%</h1>
                </div>
              </div>
              <div class="cont-extra">
                  <div style="text-align: center">
                    <p class="p-cont-extra">Rango actual:<?php echo $rango_tex ?></p>
                    <img style="width: 100px;height: 100px;" src="assets/images/estrella.png" alt="">
                    <p class="p-cont-extra">Rango próximo: <?php echo $rango_tex2 ?></p></p>
                  </div>
                  
              </div>
        </main>
    
    <style>
      * {
          padding: 0;
          margin: 0;
          box-sizing: border-box;
        }
        .container_3 {
          padding: 0px 0;
          width: 95vw;
          display: flex;
          align-items: center;
          justify-content: center;
          background-color: #dde1e7;
          flex-wrap: wrap;
        }
        .bar {
          display: inline-block;
          height: 200px;
          width: 200px;
          border-radius: 50%;
          position: relative;
          box-shadow: -3px -3px 7px #ffffffb2, 3px 3px 5px rgba(94, 104, 121, 0.945);
          overflow: hidden;
          margin: 50px;
        }
        .bar:after {
          content: "";
          position: absolute;
          left: 50%;
          top: 50%;
          transform: translate(-50%, -50%);
          height: 80%;
          width: 80%;
          border-radius: 50%;
          box-shadow: inset -3px -3px 7px #ffffffb0,
            inset 3px 3px 5px rgba(94, 104, 121, 0.692);
        }
        svg {
          width: 100%;
          height: 100%;
          position: relative;
        }
        
        svg circle {
          position: absolute;
          transform: scale(0.939);
          transform-origin: center;
          fill: none;
          stroke: rgba(220, 20, 60, 0.308);
          stroke-width: 30px;
          stroke-dasharray: 630px;
          /* stroke-dashoffset: 630px; */
        }
        .bar:nth-child(1) svg circle {
          animation: bar_1 1s ease forwards;
        }
        .bar:nth-child(2) svg circle {
          animation: bar_2 1s ease forwards;
        }
        .bar:nth-child(3) svg circle {
          animation: bar_3 1s ease forwards;
        }
        h1 {
          position: absolute;
          font-size: 20px;
          font-family: "Montserrat";
          text-align: center;
          top: 36%;
          left: 50%;
          transform: translate(-50%, -50%);
        }
        /* svg circle {
            stroke-dashoffset: calc(950 - (950*10) / 100);
        } */
        @keyframes bar_1 {
          0% {
            stroke-dashoffset: 630px;
          }
          100% {
            stroke-dashoffset: calc(630px - (630px * <?php echo $porcentaje ?>) / 100);
          }
        }
        @keyframes bar_2 {
          0% {
            stroke-dashoffset: 630px;
          }
          100% {
            stroke-dashoffset: calc(630px - (630px * 85) / 100);
          }
        }
        @keyframes bar_3 {
          0% {
            stroke-dashoffset: 630px;
          }
          100% {
            stroke-dashoffset: calc(630px - (630px * 10) / 100);
          }
        }
  
    </style>
    
</div>
    
</body>
</html>