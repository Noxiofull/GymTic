<?php

    session_start();

    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
      echo '
           <script>
              window.location = "login.html";
           </script>
      ';
      session_destroy();
    }
    else{
        $nombre = $_SESSION['usuario'];
     
        $query = "SELECT * FROM usuarios";
        $ejecutar = mysqli_query($conexion, $query);
                        
        while($linea = mysqli_fetch_array($ejecutar)){
            if($nombre == $linea['nombre']){

                $id = $linea['id'];
                $peso_user = $linea['peso'];
                $calorias_user = $linea['calorias'];
                $kilometros_user = $linea['k_metros'];
                $puntos_user = $linea['puntos'];
            }      
        }

        $query = "SELECT * FROM ejercicios";
        $ejecutar = mysqli_query($conexion, $query);
                        
        while($linea = mysqli_fetch_array($ejecutar)){

            $sw = 0;
            if($id == $linea['id_deportista'] && $linea['estado'] == 0){

                $sw = 1;
                $numero = $linea['numero'];
                $tipo = $linea['tipo'];
                $peso = $linea['peso'];
                $tiempo = $linea['tiempo'];
                $repeticiones = $linea['repeticiones'];
                break;
            }      
        }

        if($sw == 0){
            echo '
            <script>
                window.location = "ejercicio.php";
            </script>
            ';
        }

        if($numero == 1) $nombre_ejer = "Bicicleta";
        elseif($numero == 2) $nombre_ejer = "Trotar";
        elseif($numero == 3) $nombre_ejer = "Caminar";
        elseif($numero == 4) $nombre_ejer = "Levantamiento de pesas";
        elseif($numero == 5) $nombre_ejer = "Mancuernas";
        elseif($numero == 6) $nombre_ejer = "Maquina de biceps";
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <div class="principal">
        <header>
            <nav>
                <div class="nav-wrapper red" style="background-color: red">
                    <div class="card_2" style="padding: 0;justify-content:left;">
                        
                        <p style="font-size: 20px;padding-left: 90px;"><?php echo $nombre_ejer ?></p>
                    </div>
                </div>
              </nav>
        </header>
        <main>
            <div style="text-align: center;">
                <div class="cont-excercise">

                    <?php 
                    if($tipo == 1){
                    ?>
                    <div class="card_4">
                        <img class="icon-image_2" src="assets/images/1599518-gym/png/020-kettlebell.png" alt="">
    
                        <input placeholder="KG" value=<?php echo $peso ?> style="width: 200px;height: 30px; border: 1px solid black;" type="text">
                        
                    </div>
                    <?php 
                    }
                    ?>

                    <div class="card_4">
                        <img class="icon-image_2" src="assets/images/1599518-gym/png/022-chronometer.png" alt="">

                        <input placeholder="M/S" value=<?php echo $tiempo ?> style="width: 200px;height: 30px; border: 1px solid black;" type="text"> 
                    </div>

                    <?php 
                    if($tipo == 1){
                    ?>
                    <div class="card_4">
                        <img class="icon-image_2" src="assets/images/1599518-gym/png/033-whistle.png" alt="">

                        <input placeholder="N" value=<?php echo $repeticiones ?> style="width: 200px;height: 30px; border: 1px solid black;" type="text">
                    </div>
                    <?php 
                    }
                    ?>
                </div>
                <div class="crono" >
                    <div class="min" style="display: inline-block;"><?php if($tiempo<10){
                     echo '0';} echo $tiempo ?></div>:
                    <div class="seg" style="display: inline-block;">00</div>
                </div>
      
            </div>
            
            <div class="cont-all" style="flex-direction: column;align-items: center;">
            
                
                <a id="begin" href="?"><img class="flechas" src="
                assets/images/lado-derecho.png" alt=""></a>
            </div>
        </main>
    </div>
    <div class="res"></div>
    <script src="./jquery.js" ></script>
    <script>
        $("#begin").css({display:"none"})    
        const minD=document.querySelector(".min")
		const segD=document.querySelector(".seg")
		var ciclo;
          

        start();
        ciclo = setInterval(start,1000);

        function stop() {
			clearInterval(id)
		}
        function start() {
			console.log("ok")
			
	    	  let m = parseInt(minD.innerText)
	    	  let s = parseInt(segD.innerText)
	    	  s--;
    		if (s<0){
    			m--
    			s=59
    		}
    		 
    		if(m<=0 && s<=0){
    			m=0
    			s=0
    			clearInterval(ciclo);

                Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Terminado',
                showConfirmButton: false,
                timer: 2000
                });                         

                $("#begin").css({display:"block"}) 
                $.ajax({
                  method: "get",
                  url: "php/prueba.php",
                  data: { <?php echo "'puntos_user':'$puntos_user','numero':'$numero',
                            'peso_user':'$peso_user',
                            'calorias_user':'$calorias_user',
                            'tiempo':'$tiempo',
                            'kilometros_user':'$kilometros_user',
                            'id':'$id' ";?> },
                    success:(e)=>{
                       
                    }
                })
    		}
			if (s<10 ){
				segD.innerText="0"+s
			}else{
				segD.innerText=s
			}
    		if (m<10 ){
    			minD.innerText="0"+m
    		}else{
    			minD.innerText=m
    		}
					/*

        
                    */
	}	
    </script>
</body>
</html>