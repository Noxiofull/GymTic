
<?php
    include 'php/conexion.php';

    //var_dump($_POST);

    $nombre = $_GET['usuario'];  
    
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <div class="principal" style="display: flex;align-items: center;">
        <div class="column-encuesta">
            <form action="php/register_encuesta.php?usuario=<?php echo $nombre ?>" method="POST">
            <div style="display: flex;flex-direction: column;">
                <p>1 ¿Cual es tu edad?</p>
                <input type="text" name="edad">
                <p>2 ¿Cual es tu peso(KG)?</p>
                <input type="text" name="peso">
                <p>3 ¿Cual es tu estatura(CM)?</p>
                <input type="text" name="altura">
                <button class="waves-effect waves-light btn red" >envíar</button>
            </div>
            </form>
        </div>
    </div>
</body>
</html>