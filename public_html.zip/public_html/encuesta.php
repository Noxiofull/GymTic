
<?php
    include 'php/conexion.php';

    //var_dump($_POST);

    $nombre = $_GET['usuario'];  
    

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head> 
<body>
    <div class="principal" style="display: flex;align-items: center;">
            <div class="column-encuesta">
                    <div style="display: flex;align-items: center">
                    <p style="font-size: 21px;padding-top: 10px;padding-right: 5px;padding-bottom: 25px;">Bienvenido a la familia  </p>
                    <img src="assets/images/titulo.png"  style="width: 50px;height: 50px;" alt="">
                    </div>
                    <p style="font-size: 20px;">Realizar la encuesta</p>
                    <p style="font-size: 20px;">Aquí</p>
                    <a href="encuesta2.php?usuario=<?php echo $nombre ?>"><img src="assets/images/avanzar.png" style="width: 100px;height: 100px;" alt=""></a>
                    
                </div>
        </div>

</body>
</html>