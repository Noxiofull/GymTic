<?php

    session_start();

    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
      echo '
           <script>
              window.location = "login.html";
           </script>
      ';
      session_destroy();
    }
    else{
        $nombre = $_SESSION['usuario'];
     
        $query = "SELECT * FROM usuarios";
        $ejecutar = mysqli_query($conexion, $query);
                        
        while($linea = mysqli_fetch_array($ejecutar)){
            if($nombre == $linea['nombre']){

                $id = $linea['id'];
            }      
        }

        $numero = $_GET['numero'];

        if($numero == 1) $nombre_ejer = "Bicicleta";
        elseif($numero == 2) $nombre_ejer = "Trotar";
        elseif($numero == 3) $nombre_ejer = "Caminar";
        elseif($numero == 4) $nombre_ejer = "Levantamiento de pesas";
        elseif($numero == 5) $nombre_ejer = "Mancuernas";
        elseif($numero == 6) $nombre_ejer = "Maquina de biceps";


        $query = "SELECT * FROM ejercicios";
        $ejecutar = mysqli_query($conexion, $query);
                        
        while($linea = mysqli_fetch_array($ejecutar)){
            if($id == $linea['id_deportista'] && $numero == $linea['numero']){

                $tiempo = $linea['tiempo'];
                $peso = $linea['peso'];
                $repeticiones = $linea['repeticiones'];
            }      
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--Import Google Icon Font-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Compiled and minified CSS -->
<link rel="stylesheet" href="cambios.css">
<!--Import materialize.css-->
<link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>



<!--Let browser know website is optimized for mobile-->
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-wrapper red" style="background-color: red">
                <div class="card_2" style="padding: 0;justify-content:space-between;">
                <a href="ejercicio.php"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a>
                    <p style="font-size: 20px;"><?php echo $nombre_ejer ?></p>
                    <a href="anotaciones.php"><img style="width: 40px;height: 40px;" src="assets/images/1599518-gym/png/041-weight.png" alt=""></a>
                    
                </div>
            
              
            </div>
          </nav>
    </header>
    <main>
        <div class="principal">
            <div  class="image-estadistica">
                <img src="assets/images/ejercicios.jpg" alt="">
            </div>
            <div style="width: 100vw;display: flex;justify-content: center;">
                <div class="caja">
                    <p style="color: white;"><?php echo 'Repeticiones:  '.$repeticiones.'        Tiempo:'.$tiempo ?></p>
                </div>
            </div>
            <div class="columna">
                <div class="listado-ejercicio">

                    <form action="php/guardar_datos.php?numero=<?php echo $numero ?>&id=<?php echo $id ?>" method="POST">
                    <?php 
                    if($numero > 3){ 
                    ?>
                    <div class="card_4">
                        <img class="icon-image_2" src="assets/images/1599518-gym/png/020-kettlebell.png" alt="">
    
                        <input placeholder="KG" style="width: 200px;height: 30px; border: 1px solid black;" name="peso" type="number" min="0" value=<?php echo $peso ?> readonly>
                        <div class="botones-lados">
                            <img class="flechas" onclick="mover(this,0)" src="assets/images/lado-izquierdo.png" alt="">
                            <img class="flechas" onclick="mover(this,1)" src="assets/images/lado-derecho.png" alt="">
                        </div>
                    </div>

                    <?php
                    }
                    ?>
                    <div class="card_4">
                        <img class="icon-image_2" src="assets/images/1599518-gym/png/022-chronometer.png" alt="">
    
                        <input placeholder="M/S" style="width: 200px;height: 30px; border: 1px solid black;" name="tiempo" type="number" min="0" value=<?php echo $tiempo ?> readonly>
                        <div class="botones-lados">
                            <img class="flechas" onclick="mover(this,0)" src="assets/images/lado-izquierdo.png" alt="">
                            <img class="flechas" onclick="mover(this,1)" src="assets/images/lado-derecho.png" alt="">

                        </div>
                    </div>
                    <?php 
                    if($numero > 3){ 
                    ?>
                    <div class="card_4">
                        <img class="icon-image_2" src="assets/images/1599518-gym/png/033-whistle.png" alt="">
    
                        <input placeholder="N" style="width: 200px;height: 30px; border: 1px solid black;" name="repeticiones" type="number" min="0" value=<?php echo $repeticiones ?> readonly>
                        <div class="botones-lados">
                            <img class="flechas" onclick="mover(this,0)" src="assets/images/lado-izquierdo.png" alt="">
                            <img class="flechas" onclick="mover(this,1)" src="assets/images/lado-derecho.png" alt="">

                        </div>
                    </div>
                    <?php
                    }
                    ?>
                      <div style="display:flex;justify-content: center;padding-left:100px">
                      <button    class="waves-effect waves-light btn red">Guardar</button>
                      </div>
                      
                    </form>
                </div>

            </div>
            
        </div>
        
    </main>
    <script type="text/javascript">
        
        function mover(btn,est){
            var inp = btn.parentNode.parentNode.children[1];
            if(est == 1){
                inp.value++; 
            }
            else{
                if(inp.value!=0) inp.value--; 
            }
        }
        
    </script>
</body>
</html>