<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>
    <title>Document</title>
</head>
<body>

            <!-- <script>
            Swal.fire({
                title: 'Se actualizo los datos con exitos',
                timer: 3000,
                timerProgressBar: false
              });
            </script> -->
</body>
</html>

<?php
    include 'conexion.php';

    //var_dump($_POST);

    $usuario = $_GET['usuario'];  
    $edad = $_POST['edad'];
    $peso = $_POST['peso'];
    $altura = $_POST['altura'];

    $query = "UPDATE usuarios SET edad='$edad', peso='$peso', altura='$altura' WHERE nombre='$usuario'";
    

    $ejecutar = mysqli_query($conexion, $query);

    if(!empty($ejecutar)){
        echo"
            <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Registró de la encuesta completo',
                showConfirmButton: false,
                timer: 2000
              });
              setTimeout(() =>{
                window.location = '../encuesta3.html';
            },2000)             
            </script>
        ";
    }
    else{
        echo"
            <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error con el registro de usuario',
              });
              setTimeout(() =>{
                window.location = '../registro.html';
            },2000)
            </script>
        ";
    }

?>