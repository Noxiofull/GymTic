<?php session_start();?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>
    <title>Document</title>
</head>
<body>

            <!-- <script>
            Swal.fire({
                title: 'Se actualizo los datos con exitos',
                timer: 3000,
                timerProgressBar: false
              });
            </script> -->
</body>
</html>

<?php
    
    include 'conexion.php';

    //var_dump($_POST);



    $usuario = $_POST['usuario'];
    $clave = $_POST['clave'];


    $login = mysqli_query($conexion, "SELECT * FROM usuarios WHERE
        nombre='$usuario' and clave='$clave'");

    if(mysqli_num_rows($login) > 0){
        $_SESSION['usuario'] = $usuario;
        echo '
            <script>
                window.location = "../index.php";
            </script>
        ';
    }
    else{
        session_destroy();
        echo "
            <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error el usuario no existe',
              });
              setTimeout(() =>{
                window.location = '../login.html';
            },2000)    
              ;
            </script>
        ";
    }

?>