<?php session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>
<body>
	
</body>
</html>
<?php
    include 'conexion.php';

    
    if(!isset($_SESSION['usuario'])){
        echo '
            <script>
              window.location = "login.html";
            </script>
        ';
        //session_destroy();
    }
    else{
        $entrenador = $_SESSION['usuario'];
    }

    $usuario = $_GET['usuario'];  
    $numero_ejerc = $_GET['numero'];
    
    $tiempo = 0;
    $peso = 0;
    $repeticiones = 0;

    $estado = 1;
  
    $query = "SELECT * FROM usuarios";
    $ejecutar = mysqli_query($conexion, $query);

    while($linea = mysqli_fetch_array($ejecutar)){
        if($linea['nombre'] == $entrenador){
            $id_entr = $linea['id'];
        }
        if($linea['nombre'] == $usuario){
            $id_user = $linea['id'];
        }
    }

    if($numero_ejerc <= 3){
        $tipo = 0;
    }
    else{
        $tipo = 1;
    }
    
    //echo $id_user." - ".$id_entr." - ".$tipo." - ".$numero_ejerc." - ".$tiempo." - ".$peso." - ".$repeticiones;


    $query = "INSERT INTO ejercicios (id_deportista, id_entrenador, tipo, numero, tiempo, peso, repeticiones, estado) VALUES('$id_user', '$id_entr', '$tipo', '$numero_ejerc','$tiempo','$peso','$repeticiones','$estado')";

    
    $row = mysqli_query($conexion, $query);
    
    if($row){
        echo"
            <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'El ejercicio se registro con exito',
                showConfirmButton: false,
                timer: 2000
              });
              setTimeout(() =>{
              window.location = '../perfil_usuario.php?nombre_user=$usuario';
            },2000)                       
            </script>
        ";
    }
    else{
        echo"
            <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error con el registro del ejercicio',
              });
              setTimeout(() =>{
                window.location = '../perfil_usuario.php?nombre_user=$usuario';
            },2000)                   
            </script>
        ";
    }
?>