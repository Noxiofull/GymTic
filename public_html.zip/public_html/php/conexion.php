<?php
    //error_reporting(0);
    $conexion = mysqli_connect("localhost", "id16153738_noxiofull","g58b|ouCsVWo^~<n","id16153738_basegymtic");

    if($conexion){
        echo '
            <script>
                //alert("conectado");
            </script>
        ';
    }else{
        echo '
            <script>
                alert("No conectado");
            </script>
        ';
    }
    
