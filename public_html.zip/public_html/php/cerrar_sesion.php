<?php

    session_start();
    header("location: ../login.html");
    session_destroy();

?>