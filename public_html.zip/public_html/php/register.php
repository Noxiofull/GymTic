<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>
    <title>Document</title>
</head>
<body>

            <!-- <script>
            Swal.fire({
                title: 'Se actualizo los datos con exitos',
                timer: 3000,
                timerProgressBar: false
              });
            </script> -->
</body>
</html>

<?php
    include 'conexion.php';

    //var_dump($_POST);

    $nombre = $_POST['usuario'];  
    $email = $_POST['email'];
    $clave = $_POST['clave'];
    $peso = 0;
    $edad = 0;
    $altura = 0;
    $calorias = 0;
    $k_metros = 0;
    $tipo = 1;
    $puntos = 0;
    $comentario ="NOTA";

    $query = "SELECT * FROM usuarios WHERE nombre='$nombre'";
    $ejecutar = mysqli_query($conexion, $query);
   
    $linea = mysqli_fetch_array($ejecutar);
    $query = "SELECT * FROM usuarios WHERE email='$email'";
    $ejecutar2 = mysqli_query($conexion, $query);
    $linea2 = mysqli_fetch_array($ejecutar2);
    if($linea){
        echo "
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error nombre de usuario existe',
              });
              setTimeout(() =>{
                window.location = '../registro.html';
            },2000)
            
        </script>
    ";
    }elseif($linea2){
        echo "
        <script>
        Swal.fire({
            icon: 'error',
            title: 'Oops...',
            text: 'Error el correo existe',
          });
          setTimeout(() =>{
            window.location = '../registro.html';
        },2000)
        </script>
    ";
    }else
    {
    $query = "INSERT INTO usuarios(nombre, clave, email, peso, edad, altura, calorias, k_metros, tipo, puntos,comentario) VALUES('$nombre', '$clave', '$email', '$peso', '$edad','$altura','$calorias','$k_metros','$tipo','$puntos','$comentario')";

    
    $ejecutar = mysqli_query($conexion, $query);

    if(!empty($ejecutar)){
        echo"
            <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Registró completado con exito',
                showConfirmButton: false,
                timer: 2000
              });
              setTimeout(() =>{
                window.location = '../encuesta.php?usuario=$nombre';
            },2000)          
            </script>
        ";
    }
    else{
        echo"
            <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error con el registro de usuario',
              });
              setTimeout(() =>{
                window.location = '../registro.html';
            },2000)    
            </script>
        ";
    }
    }
    

?>