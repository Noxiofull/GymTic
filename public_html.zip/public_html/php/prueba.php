<?php

include 'conexion.php';
$puntos_user=$_GET['puntos_user'];
$numero=$_GET["numero"];
$peso_user=$_GET["peso_user"];
$calorias_user=$_GET["calorias_user"];
$tiempo=$_GET["tiempo"];
$kilometros_user=$_GET["kilometros_user"];
$id=$_GET["id"];


                    $estado = 1;
        
                    $query = "UPDATE ejercicios SET estado='$estado' WHERE numero='$numero' and id_deportista='$id'";
            
                    $ejecutar = mysqli_query($conexion, $query);
                    echo "ok";

                    $puntos_user++;

                    if($numero <=3){
                        
                        if($numero == 1){
                            $met = 7;
                            $vel_ejer = 19;
                        } 
                        elseif($numero == 2){
                            $met = 8;
                            $vel_ejer = 8;
                        } 
                        elseif($numero == 3){
                            $met = 3.8;
                            $vel_ejer = 5.6;
                        }

                        $calorias = (0.0175 * $met * $peso_user) + $calorias_user;
                        $k_metros = ($vel_ejer * $tiempo) + $kilometros_user;
                        

                        $query = "UPDATE usuarios SET calorias='$calorias',k_metros='$k_metros', puntos='$puntos_user' WHERE id='$id'";
                    }
                    else{
                        $query = "UPDATE usuarios SET puntos='$puntos_user' WHERE id='$id'";
                    }
                    $ejecutar = mysqli_query($conexion, $query);
             
                
                ?>