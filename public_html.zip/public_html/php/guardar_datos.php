<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>
    <title>Document</title>
</head>
<body>

            <!-- <script>
            Swal.fire({
                title: 'Se actualizo los datos con exitos',
                timer: 3000,
                timerProgressBar: false
              });
            </script> -->
</body>
</html>
 
<?php
    
    include 'conexion.php';

    //var_dump($_POST);
    //var_dump($_GET);

    $numero = $_GET['numero']; 
    $id = $_GET['id'];
    $tiempo = $_POST['tiempo'];
    if(isset( $_POST['peso'])||isset( $_POST['repeticiones'])){
        $peso = $_POST['peso'];
        $repeticiones = $_POST['repeticiones'];
        $query = "UPDATE ejercicios SET peso='$peso', tiempo='$tiempo', repeticiones='$repeticiones' WHERE numero='$numero' and id_deportista='$id'";
    
    }else{
        $query = "UPDATE ejercicios SET  tiempo='$tiempo' WHERE numero='$numero' and id_deportista='$id'";
    }
    
    
    


    
    $ejecutar = mysqli_query($conexion, $query);


    if(!empty($ejecutar)){
        echo"
            <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Se ha actualizado el ejercicio',
                showConfirmButton: false,
                timer: 2000
              });
              setTimeout(() =>{
                window.location = '../ejercicio.php';
            },2000)
            </script>
        ";
    }
    else{
        echo"
            <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'No se ha actualizado el ejercicio',
              });
              setTimeout(() =>{
                window.location = '../ejercicio.php';
            },2000)
            </script>
        ";
    }

?>
