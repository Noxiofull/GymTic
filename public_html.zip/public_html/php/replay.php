<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@10'></script>
    <title>Document</title>
</head>
<body>

            <!-- <script>
            Swal.fire({
                title: 'Se actualizo los datos con exitos',
                timer: 3000,
                timerProgressBar: false
              });
            </script> -->
</body>
</html>

<?php
    include 'conexion.php';


    $id = $_GET['id'];
    
    $estado = 0;

    $query = "UPDATE ejercicios SET estado='$estado' WHERE id_deportista='$id'";
    
    $ejecutar = mysqli_query($conexion, $query);

    if(!empty($ejecutar)){
        echo"
            <script>
            Swal.fire({
                position: 'center',
                icon: 'success',
                title: 'Ejercicio reiniciados con exito',
                showConfirmButton: false,
                timer: 2000
              });
              setTimeout(() =>{
                window.location = '../ejercicio.php';
            },2000)                     
            </script>
        ";
    }
    else{
        echo"
            <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Error al reiniciar ejercicios',
              });
              setTimeout(() =>{
                window.location = '../ejercicio.php';
            },2000)                  
            </script>
        ";
    }

?>