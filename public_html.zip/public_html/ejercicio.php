<?php

    session_start();

    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
      echo '
           <script>
              window.location = "login.html";
           </script>
      ';
      session_destroy();
    }
    else{
        $nombre = $_SESSION['usuario'];
     
        $query = "SELECT * FROM usuarios";
        $ejecutar = mysqli_query($conexion, $query);
                        
        while($linea = mysqli_fetch_array($ejecutar)){
            if($nombre == $linea['nombre']){

                $id = $linea['id'];
            }      
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css?1.1">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <header>
        <nav>
        <div class="card_2" style="padding: 0;justify-content:left;background-color: red">
                <a href="index.php"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a>
                    <p style="color: white; font-size: 20px;padding-left: 90px;">Lista de ejercicio</p>
                </div>
          </nav>
    </header>
    <main>
        <img class="image-principal" src="assets/images/pexels-mister-mister-3490348.jpg" alt="">
        <div class="row_1">
            <div class="listado-ejercicio">

            <?php
                $query = "SELECT * FROM ejercicios";
                $ejecutar = mysqli_query($conexion, $query);
                        
                while($linea = mysqli_fetch_array($ejecutar)){
                    if($linea['id_deportista'] == $id){

                        $numero = $linea['numero'];
                        $tiempo = $linea['tiempo'];
                        $estado = $linea['estado'];

                        if($numero == 1) $name = "Bicicleta";
                        elseif ($numero == 2) $name = "Trotar";
                        elseif ($numero == 3) $name = "Caminar";
                        elseif ($numero == 4) $name = "Levantamiento de pesas";
                        elseif ($numero == 5) $name = "Mancuernas";
                        else $name = "Maquina de biceps";
            ?>
                <a href="interfazejercicios.php?numero=<?php echo $numero ?>">
                    <div class="card_2">
                        <img class="icon-image_2" src="assets/images/1599518-gym/png/046-plan.png" alt="">

                        <p><?php echo $name ?></p>
                        <p><?php echo $tiempo ?> M</p>
                        <p><?php if($estado == 0){
                            echo "Pendiente";
                        }
                        else{
                            echo "Realizado";
                        } ?></p>
                        
                    </div>
                </a>
            <?php
                    }
                }
            ?>
                
            </div>
            <div style="display:flex;justify-content: center;justify-content: space-evenly"> <a class="waves-effect waves-light btn red" href="play.php">PLAY</a>
            <a class="waves-effect waves-light btn red" href="php/replay.php?id=<?php echo $id ?>">REPLAY</a>
        </div>
            
        </div>
    </main>
    
</body>
</html>