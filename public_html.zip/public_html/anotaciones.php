<?php

    session_start();

    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
      echo '
           <script>
              window.location = "login.html";
           </script>
      ';
      session_destroy();
    }
    else{
        $nombre = $_SESSION['usuario'];
     
        $query = "SELECT * FROM usuarios";
        $ejecutar = mysqli_query($conexion, $query);
                        
        while($linea = mysqli_fetch_array($ejecutar)){
            if($nombre == $linea['nombre']){

                $id = $linea['id'];
                $comentario =$linea['comentario'];
            }      
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--Import Google Icon Font-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Compiled and minified CSS -->
<link rel="stylesheet" href="cambios.css">
<!--Import materialize.css-->
<link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>


<!--Let browser know website is optimized for mobile-->
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <div class="principal">
        <header>
            <nav>
                <div class="nav-wrapper red" style="background-color: red">
                    <div class="card_2" style="padding: 0;justify-content:left;">
                    <a href="ejercicio.php"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a>
                        
                        <p style="font-size: 20px;padding-left: 90px;">Anotaciones</p>
                    </div>
                </div>
              </nav>
        </header>
        <main style="display: flex; justify-content: center">
        <form action="php/agregar_comen.php?id=<?php echo $id?>" method="POST">
        <div style="display: flex; justify-content: center;margin-top: 20px;flex-direction: column">
            <textarea  readonly style="width:300px;height: 300px;border: 1px solid black;"  name="notas" id="" cols="30" rows="10"><?php echo $comentario ?></textarea>    

            <input name="write" type="text">
                
            </div>
            
            
            <div style="display: flex;justify-content:center;">
                <button class="waves-effect waves-light btn red ">Confirmar</button>
            </div>
        </form>    
        
            
        </main>
    </div>
    
</body>
</html>