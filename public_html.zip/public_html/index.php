<?php
    session_start();
    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
      echo '
           <script>
              window.location = "login.html";
           </script>
      ';
      
    }
    else{
        $nombre = $_SESSION['usuario'];
     
        $query = "SELECT * FROM usuarios";
        $ejecutar = mysqli_query($conexion, $query);
                        
        while($linea = mysqli_fetch_array($ejecutar)){
            if($nombre == $linea['nombre']){

                $id = $linea['id'];
                $tipo = $linea['tipo'];

                
            }      
        }
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Import Google Icon Font-->
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<!-- Compiled and minified CSS -->
<link rel="stylesheet" href="cambios.css?1.1">
<!--Import materialize.css-->
<link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>


<!--Let browser know website is optimized for mobile-->
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body style="overflow:hidden">
    <div class="principal">
                  

    <nav>
        <div class="nav-wrapper red;background-color: red" style="width:100%!important" >
          <a href="#!" class="brand-logo"></a>
          <a href="#" data-target="mobile-demo" class="sidenav-trigger"><i class="material-icons">menu</i></a>
      </nav>
    
      <ul class="sidenav" id="mobile-demo">
          <div class="cont-usuario">

                  <img   style="width: 100px;" src="assets/images/Usuario.png" alt="">
              
              <p style="text-align: center;"><?php echo $nombre ?></p>
            </div>
        
  
        <?php if($tipo == 0){
         echo  '<li><a href="listadeusuarios.php" style="text-align: center">Lista de usuarios</a></li>';
        }
        ?>
        
        <li><a href="php/cerrar_sesion.php" style="text-align: center">cerrar sesión</a></li>
      </ul>
      
      <main>
        <img class="image-principal" src="assets/images/gym2.jpg" alt="">
        <!-- Aqui van las iconos  -->
        <div class="row">
          <a href="ejercicio.php">
          <div class="card_1">
            <img class="icon-image" src="assets/images/bola1.png" alt="">
            <p>Ejercicios</p>
          </div>
          </a>
          <a href="estadistica.php">
          <div class="card_1">
            <img class="icon-image" src="assets/images/circulo2.jpg" alt="">
            <p>Estadistica</p>
          </div>
          </a>
          <a href="recompensas.php">
          <div class="card_1">
            <img class="icon-image" src="assets/images/recompensa.png" alt="">
            <p>Recompensas</p>
          </div>
          </a>
        </div>

      </main>
    </div>
      

<!-- Compiled and minified JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/js/materialize.min.js"></script>

 <script type="text/javascript">
     document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.sidenav');
    var instances = M.Sidenav.init(elems);
  });
 </script>     
</body>
</html>