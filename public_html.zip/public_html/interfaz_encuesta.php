<?php

    session_start();

    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
        echo '
            <script>
                window.location = "login.html";
            </script>
        ';
        
    }
        else{
        $nombre = $_SESSION['usuario'];
    }

    $nombre_user = $_GET['usuario'];


    $query = "SELECT * FROM usuarios";
    $ejecutar = mysqli_query($conexion, $query);
                        
    while($linea = mysqli_fetch_array($ejecutar)){
        if($nombre_user == $linea['nombre']){

            $edad = $linea['edad'];
            $peso = $linea['peso'];
            $estatura = $linea['altura'];
        }
    }
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-wrapper red">
            <div class="card_2" style="padding: 0;justify-content:left;background-color: red">
                <a href="perfil_usuario.php?nombre_user=<?php echo $nombre_user?>"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a>
                    <p style="color: white; font-size: 20px;padding-left: 90px;">Encuesta</p>
                </div>
            </div>
          </nav>
    </header>
    <div class="principal" style="display: flex;align-items: center;">
        <div class="column-encuesta">
            <div style="display: flex;flex-direction: column;">
            <p>Edad</p>
            <input type="text" value=<?php echo $edad ?>>
            <p>Peso</p>
            <input type="text" value=<?php echo $peso ?>>
            <p>Estatura</p>
            <input type="text" value=<?php echo $estatura ?>>
            </div>
                
        </div>
    </div>
</body>
</html>