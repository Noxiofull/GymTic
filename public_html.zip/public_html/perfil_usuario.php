<?php

    session_start();


    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
        echo '
            <script>
                window.location = "login.html";
            </script>
        ';
        session_destroy();
    }
        else{
        $nombre = $_SESSION['usuario'];
    }

    $nombre_user = $_GET['nombre_user'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css?1.1">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body style="overflow:hidden"> 
    <header>
        <nav>
            <div class="nav-wrapper red">
                <div class="card_2" style="padding: 0;justify-content:left;background-color: red">
                <a href="listadeusuarios.php"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a> 
             <p style="font-size: 20px;padding-left: 90px;">Lista de usuarios</p>
            </div>
            
             
            </div>
          </nav>
    </header>
    <main>
        <div class="columna-2">
            <div class="items_Usuario">
                <img style="height: 250px;" src="assets/images/usuario-de-perfil.png" alt="">
                <p style="padding-top: 20px;"><?php echo $nombre_user ?></p>
            </div>
            <a href="interfaz_encuesta.php?usuario=<?php echo $nombre_user ?>">
            <div class="items_Usuario">
                <img class="icon-image_2" src="assets/images/1599518-gym/png/046-plan.png" alt="">
                <p>Encuesta</p>
            </div>
            </a>
            <a href="interfaz_ejercicio.php?usuario=<?php echo $nombre_user ?>">
            <div class="items_Usuario" style="padding-top:0">
                <img class="icon-image_2"  src="assets/images/1599518-gym/png/046-plan.png" alt="">
                <p>Asignar ejercicios</p>
            </div>
            </a>
        </div>
    </main>
</body>
</html>