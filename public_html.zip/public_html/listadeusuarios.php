<?php

    session_start();

    include 'php/conexion.php';

    if(!isset($_SESSION['usuario'])){
        
    echo '
        <script>
            window.location = "login.html";
        </script>
    ';
    session_destroy();
    }
    else{
    $nombre = $_SESSION['usuario'];
    }

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!--Import Google Icon Font-->
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <!-- Compiled and minified CSS -->
        <link rel="stylesheet" href="cambios.css">
        <!--Import materialize.css-->
        <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
        
        
        <!--Let browser know website is optimized for mobile-->
        <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <header>
        <nav>
            <div class="nav-wrapper red" style="background-color: red">
            <div class="card_2" style="padding: 0;justify-content:left;background-color: red">
                <a href="index.php"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a> 
             <p style="font-size: 20px;padding-left: 90px;">Lista de usuarios</p>
            </div>
          </nav>
    </header>
    <main>
        <div class="columna">
            <div class="listado-ejercicio">

            <?php
                $query = "SELECT * FROM usuarios";
                $ejecutar = mysqli_query($conexion, $query);
                        
                while($linea = mysqli_fetch_array($ejecutar)){

                    $nombre_user = $linea['nombre'];
                
            ?>
                <a href="perfil_usuario.php?nombre_user=<?php echo $nombre_user ?>">
                <div class="card_2">
                    <img class="icon-image_2" src="assets/images/Usuario.png" alt="">

                    <p><?php echo $nombre_user ?></p>
                    <img class="icon-image_2" src="assets/images/1599518-gym/png/045-lockers.png" alt="">
                </div>
                </a>
            <?php 
                }
            ?>
                
            </div>
        </div>
    </main>  
</body>
</html>