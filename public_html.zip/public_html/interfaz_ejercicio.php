<?php

session_start();

include 'php/conexion.php';


if(!isset($_SESSION['usuario'])){
    
    echo '
        <script>
            window.location = "login.html";
        </script>
    ';
  //  session_destroy();
}
    else{
    $nombre = $_SESSION['usuario'];
}

$nombre_user = $_GET['usuario'];


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css?1.8">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body>
    <div class="principal">
        <header>
            <nav>
                <div class="nav-wrapper red" style="background-color: red">
                    <div class="card_2" style="padding: 0;justify-content:left;">
                    <a href="perfil_usuario.php?nombre_user=<?php echo $nombre_user?>"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a>
                        <p style="font-size: 20px;padding-left: 125px;">Ejercicios</p>
                    </div>
                </div>
              </nav>
        </header>
        <main>
            <div style="text-align: center;">
                <p style="margin:50px;font-size:50px">Listado de ejercicios</p>
            </div>
            <div class="cont-all">
                <div class="lado-izquierdo">
                    <p style="font-size:40px">Cardio</p>
                    <div class="cont-cardio">
                        <a href="php/asignar_ejerc.php?usuario=<?php echo $nombre_user ?>&numero=<?php echo 1 ?>"><p class="card">Bicicleta</p></a>
                        <a href="php/asignar_ejerc.php?usuario=<?php echo $nombre_user ?>&numero=<?php echo 2 ?>"><p class="card">Trotar</p></a>
                        <a href="php/asignar_ejerc.php?usuario=<?php echo $nombre_user ?>&numero=<?php echo 3 ?>"><p class="card">Caminar</p></a>
                    </div>
                </div>
                
                <div class="lado-derecho">
                    <p style="font-size:40px">Pesas</p>
                    <div class="cont-pesa">
                        <a href="php/asignar_ejerc.php?usuario=<?php echo $nombre_user ?>&numero=<?php echo 4 ?>"><p class="card">Levantamiento de pesas</p></a>
                        <a href="php/asignar_ejerc.php?usuario=<?php echo $nombre_user ?>&numero=<?php echo 5 ?>"><p class="card">Mancuernas</p></a>
                        <a href="php/asignar_ejerc.php?usuario=<?php echo $nombre_user ?>&numero=<?php echo 6 ?>"><p class="card">Maquina de biceps</p></a>
                    </div> 
                </div>
            </div>
        </main>
    </div>
    
</body>
</html>