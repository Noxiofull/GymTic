<?php

session_start();

include 'php/conexion.php';

if(!isset($_SESSION['usuario'])){
    
  echo '
       <script>
          window.location = "login.html";
       </script>
  ';
  session_destroy();
}
else{
    $nombre = $_SESSION['usuario'];
 
    $query = "SELECT * FROM usuarios";
    $ejecutar = mysqli_query($conexion, $query);
                    
    while($linea = mysqli_fetch_array($ejecutar)){
        if($nombre == $linea['nombre']){

            $id = $linea['id'];

            $calorias = $linea['calorias'];
            $kilometros = $linea['k_metros'];
            $peso = $linea['peso'];
            
            $peso_per = (int)($calorias/7000);
            $peso -= $peso_per;

            break;
        }      
    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--Import Google Icon Font-->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <!-- Compiled and minified CSS -->
    <link rel="stylesheet" href="cambios.css">
    <!--Import materialize.css-->
    <link type="text/css" rel="stylesheet" href="materialize/css/materialize.min.css"  media="screen,projection"/>
    
    
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Document</title>
</head>
<body style="overflow:hidden">
    <header>
        <nav>
            <div class="nav-wrapper red">
                    <div class="card_2" style="padding: 0;justify-content:left;">
                    <a href="index.php"><img style="width: 40px;height: 40px;" src="assets/images/flechas.png" alt=""></a>
                        
                        <p style="font-size: 20px;padding-left: 110px;">Estadística</p>
                    </div>
                </div>
          </nav>
    </header>
    <main>
        <div class="principal">
            <div  class="image-estadistica">
                <img src="assets/images/estadistica.png" alt="">
            </div>
            <div class="columna-3">
                <div class="listado-ejercicio">
                    <div class="card_3">
                        <img class="icon-image_3" src="assets/images/1599518-gym/png/048-burn.png" alt="">
    
                        <p>Calorias <?php echo ": ".$calorias ?></p>
                        
                    </div>
                    <div class="card_3">
                        <img class="icon-image_3" src="assets/images/1599518-gym/png/016-sneaker.png" alt="">
    
                        <p>Kilometros Recorridos <?php echo ": ".$kilometros ?></p>
                        
                    </div>
                    <div class="card_3">
                        <img class="icon-image_3" src="assets/images/1599518-gym/png/021-scale.png" alt="">
    
                        <p>Peso actual aprox <?php echo ": ".$peso ?></p>
                        
                    </div>
                </div>
            </div>
        </div>
        

    </main>
</body>
</html>